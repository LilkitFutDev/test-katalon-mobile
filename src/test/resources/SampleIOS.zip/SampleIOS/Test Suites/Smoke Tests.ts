<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Smoke Tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>748008ba-a996-4389-b95e-9e16e42d61db</testSuiteGuid>
   <testCaseLink>
      <guid>4cfd9246-e3f7-450d-bcd0-ea51eb13469d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify the main list</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b6d935b6-c142-4d24-99b2-39a0b3d454bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mexican Coffee Timer</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
