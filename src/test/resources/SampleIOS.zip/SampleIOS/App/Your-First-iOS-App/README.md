Your-First-iOS-App
==================

Sample code for my [book](https://leanpub.com/your-first-ios-app) – the [first chapter is available online for free](http://yourfirstiosapp.com). I start out small and incrementally introduce new concepts to build a simple timer application. 

Design uses elements from the [Teehan+Lax iPhone PSD](http://www.teehanlax.com/tools/iphone/).

![Root view](http://static.ashfurrow.com/github/rootView.png)

![Edit view](http://static.ashfurrow.com/github/editView.png)

![Timer view](http://static.ashfurrow.com/github/timerView.png)

