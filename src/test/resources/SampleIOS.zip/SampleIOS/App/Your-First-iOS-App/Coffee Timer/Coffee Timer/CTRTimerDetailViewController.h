//
//  CTRTimerDetailViewController.h
//  Coffee Timer
//
//  Created by Ash Furrow on 2013-03-23.
//  Copyright (c) 2013 Ash Furrow. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CTRTimerModel.h"

@interface CTRTimerDetailViewController : UIViewController

@property (nonatomic, strong) CTRTimerModel *timerModel;

@end
