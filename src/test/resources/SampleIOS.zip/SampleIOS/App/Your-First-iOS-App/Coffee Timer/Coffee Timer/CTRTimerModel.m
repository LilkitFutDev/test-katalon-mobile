//
//  CTRTimerModel.m
//  Coffee Timer
//
//  Created by Ash Furrow on 2013-05-05.
//  Copyright (c) 2013 Ash Furrow. All rights reserved.
//

#import "CTRTimerModel.h"


@implementation CTRTimerModel

@dynamic name;
@dynamic duration;
@dynamic type;
@dynamic displayOrder;

@end
